ENV_VAR: dict = {
    "dev": {
        "host": "dev"
    },
    "prod": {
        "host": "prod"
    },
    "test": {
        "host": "test"
    }
}
SCHEMA = "squema"
RAW_TABLE = "table_name"

RAW_COLUMNS: list = ['column1', 'column2', 'column3']

TRANS_COLUMNS: list = ['column1', 'column2', 'column3', 'column4']
